#pragma once
#include <chrono>

double Cholesky(int N, bool debug = false);
