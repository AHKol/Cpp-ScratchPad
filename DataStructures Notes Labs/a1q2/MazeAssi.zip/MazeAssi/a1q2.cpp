#include "maze.h"

int findPath (Maze& theMaze, const Coord& start, const Coord& end, Coord path[]){

}